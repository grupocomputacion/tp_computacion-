#!/bin/bash

# Validar argumentos
if [["$1" == "-help" ||$# -ne 2]]; then
   echo "Uso: $0 <directorio_origen> <directorio_destio>"
   echo "Ejemplo :$0 /var/log /backup_dir"
   exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(DATE +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_BKP_${FECHA}.tar.gz

# Validar si origen y destino existen y estan montados 

if [!-d "$ORIGEN"]; then
   echo "El directorio origen $ORIGEN no esta montado o no existe"
   exit 1
fi 

if !mountpoint -q "$DESTINO"; then
   echo "El directorio destio $DESTINO no esta montado o no existe"
   exit 1
fi 

# Ejecutar Backup

tar -czf "$DESTINO/$NOMBRE" "$ORIGEN" 2>/dev/null

if [[$? -eq 0]]; then
   echo "Backup exitoso : $DESTINO/$NOMBRE"
else
   echo "Hubo un error durante el backup"
fi


